package app.m02print

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Cool thermal-paper greys, near-black ink, one teal accent.
private val Scheme = lightColorScheme(
    primary = Color(0xFF14181C),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE3E6),
    onPrimaryContainer = Color(0xFF14181C),
    secondary = Color(0xFF0F766E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCDEBE7),
    onSecondaryContainer = Color(0xFF053D39),
    background = Color(0xFFF1F3F4),
    onBackground = Color(0xFF14181C),
    surface = Color(0xFFF1F3F4),
    onSurface = Color(0xFF14181C),
    surfaceVariant = Color(0xFFE2E6E8),
    onSurfaceVariant = Color(0xFF454C52),
    surfaceContainerLow = Color(0xFFF7F8F9),
    surfaceContainer = Color(0xFFEDF0F1),
    surfaceContainerHigh = Color(0xFFE6EAEC),
    outline = Color(0xFF7A838A),
    outlineVariant = Color(0xFFC6CCD0)
)

@Composable
fun M02Theme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
