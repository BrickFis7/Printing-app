package app.m02print

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

data class Found(val name: String, val addr: String)

/**
 * Phomemo M02 / T02 style protocol (ESC/POS-like raster).
 * If your unit behaves differently, this is the one place to tweak.
 */
object M02 {
    private const val BLOCK_ROWS = 256

    fun job(m: Mono, density: Int, tailRows: Int, copies: Int): ByteArray {
        val out = ByteArrayOutputStream()
        repeat(copies.coerceAtLeast(1)) { one(out, m, density, tailRows) }
        return out.toByteArray()
    }

    private fun one(out: ByteArrayOutputStream, m: Mono, density: Int, tailRows: Int) {
        val wb = m.rowBytes
        out.write(byteArrayOf(0x1B, 0x40))                                  // init
        out.write(byteArrayOf(0x1B, 0x61, 0x01))                            // centre
        out.write(byteArrayOf(0x1F, 0x11, 0x02, density.coerceIn(1, 15).toByte())) // darkness
        val rows = m.h + tailRows
        var y = 0
        while (y < rows) {
            val n = minOf(BLOCK_ROWS, rows - y)
            // GS v 0 : raster bit image, normal mode, xL xH yL yH
            out.write(
                byteArrayOf(
                    0x1D, 0x76, 0x30, 0x00,
                    (wb and 0xFF).toByte(), ((wb shr 8) and 0xFF).toByte(),
                    (n and 0xFF).toByte(), ((n shr 8) and 0xFF).toByte()
                )
            )
            for (r in y until y + n) {
                if (r < m.h) {
                    val row = m.bits.copyOfRange(r * wb, (r + 1) * wb)
                    // 0x0A inside raster data makes some firmwares stop; nudge those bytes.
                    for (i in row.indices) if (row[i] == 0x0A.toByte()) row[i] = 0x14
                    out.write(row)
                } else {
                    out.write(ByteArray(wb))
                }
            }
            y += n
        }
        out.write(byteArrayOf(0x1B, 0x64, 0x02, 0x1B, 0x64, 0x02))          // feed
        out.write(byteArrayOf(0x1F, 0x11, 0x08, 0x1F, 0x11, 0x0E, 0x1F, 0x11, 0x07, 0x1F, 0x11, 0x09)) // end
    }
}

@SuppressLint("MissingPermission")
class PrinterManager(private val ctx: Context) {
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private val spp: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun bonded(): List<Found> = runCatching {
        adapter?.bondedDevices.orEmpty()
            .map { Found(it.name ?: it.address, it.address) }
            .sortedByDescending { likely(it.name) }
    }.getOrDefault(emptyList())

    private fun likely(n: String) = n.contains("M02", true) || n.contains("phomemo", true) || n.contains("T02", true)

    /** Starts a BLE scan; returns a function that stops it. */
    fun scan(onFound: (Found) -> Unit): () -> Unit {
        val sc = adapter?.bluetoothLeScanner ?: return {}
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val n = result.scanRecord?.deviceName ?: result.device.name ?: return
                onFound(Found(n, result.device.address))
            }
        }
        sc.startScan(cb)
        return { runCatching { sc.stopScan(cb) } }
    }

    /** Sends [data]. Tries the remembered link type first. Returns true if BLE was used. */
    suspend fun send(addr: String, data: ByteArray, bleFirst: Boolean, bytesPerSec: Int): Result<Boolean> =
        withContext(Dispatchers.IO) {
            runCatching {
                val ad = adapter ?: throw IOException("Bluetooth not available")
                if (!ad.isEnabled) throw IOException("Bluetooth is turned off")
                val dev = ad.getRemoteDevice(addr)
                ad.cancelDiscovery()
                val errors = ArrayList<String>()
                for (ble in if (bleFirst) listOf(true, false) else listOf(false, true)) {
                    try {
                        if (ble) sendBle(dev, data, bytesPerSec.coerceAtLeast(500)) else sendClassic(dev, data, bytesPerSec.coerceAtLeast(500))
                        return@runCatching ble
                    } catch (e: Exception) {
                        errors.add((if (ble) "BLE: " else "Classic: ") + (e.message ?: e.javaClass.simpleName))
                    }
                }
                throw IOException(errors.joinToString(" | "))
            }
        }

    private fun sendClassic(dev: BluetoothDevice, data: ByteArray, bps: Int) {
        val sock = dev.createRfcommSocketToServiceRecord(spp)
        try {
            sock.connect()
            val out = sock.outputStream
            val input = sock.inputStream
            Thread.sleep(300)
            while (input.available() > 0) input.read()      // drop any greeting bytes
            // Feed the printer no faster than it can print. Android's write() returns as soon as the
            // phone's own buffer accepts the data, so closing early would throw the rest away.
            var off = 0
            while (off < data.size) {
                val n = minOf(256, data.size - off)
                out.write(data, off, n)
                out.flush()
                off += n
                Thread.sleep(maxOf(5L, n * 1000L / bps))
            }
            // The job ends with status queries; the printer answers once it has taken all the data.
            val end = System.currentTimeMillis() + 5000
            while (System.currentTimeMillis() < end && input.available() == 0) Thread.sleep(100)
            Thread.sleep(2500) // let it finish printing what is still in its buffer
        } finally {
            runCatching { sock.close() }
        }
    }

    @Suppress("DEPRECATION")
    private fun sendBle(dev: BluetoothDevice, data: ByteArray, bps: Int) {
        val q = LinkedBlockingQueue<String>()
        var mtu = 23
        val cb = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                q.put(if (newState == BluetoothProfile.STATE_CONNECTED) "connected" else "disconnected")
            }

            override fun onMtuChanged(gatt: BluetoothGatt, m: Int, status: Int) {
                if (status == BluetoothGatt.GATT_SUCCESS) mtu = m
                q.put("mtu")
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                q.put(if (status == BluetoothGatt.GATT_SUCCESS) "services" else "disconnected")
            }
        }

        fun expect(ev: String, ms: Long) {
            val end = System.currentTimeMillis() + ms
            while (true) {
                val left = end - System.currentTimeMillis()
                if (left <= 0) throw IOException("timeout waiting for $ev")
                val got = q.poll(left, TimeUnit.MILLISECONDS) ?: continue
                if (got == ev) return
                if (got == "disconnected") throw IOException("disconnected")
            }
        }

        val gatt = dev.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
        try {
            expect("connected", 10000)
            if (gatt.requestMtu(247)) runCatching { expect("mtu", 2500) }
            gatt.discoverServices()
            expect("services", 10000)

            val chars = gatt.services
                .filterNot { it.uuid.toString().startsWith("00001800") || it.uuid.toString().startsWith("00001801") }
                .flatMap { it.characteristics }
                .filter {
                    it.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or
                        BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                }
            val ch = chars.firstOrNull { it.uuid.toString().startsWith("0000ff02") }
                ?: chars.firstOrNull()
                ?: throw IOException("no writable characteristic")

            val noResp = ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
            ch.writeType = if (noResp) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            val chunk = (mtu - 3).coerceIn(20, 180)

            var off = 0
            while (off < data.size) {
                val n = minOf(chunk, data.size - off)
                ch.value = data.copyOfRange(off, off + n)
                var tries = 0
                while (!gatt.writeCharacteristic(ch)) {      // false = stack busy, retry
                    if (++tries > 300) throw IOException("write failed")
                    Thread.sleep(10)
                }
                off += n
                Thread.sleep(maxOf(10L, n * 1000L / bps))
            }
            Thread.sleep(5000)
        } finally {
            runCatching { gatt.disconnect() }
            runCatching { gatt.close() }
        }
    }
}
