package app.m02print

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/** 1-bit image, MSB first, 1 = black. */
class Mono(val w: Int, val h: Int, val bits: ByteArray) {
    val rowBytes: Int get() = (w + 7) / 8

    fun toBitmap(): Bitmap {
        val rb = rowBytes
        val px = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val on = (bits[y * rb + (x shr 3)].toInt() and (0x80 shr (x and 7))) != 0
            px[y * w + x] = if (on) Color.BLACK else Color.WHITE
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}

fun Bitmap.toMono(threshold: Int = 140): Mono {
    val w = width
    val h = height
    val rb = (w + 7) / 8
    val px = IntArray(w * h)
    getPixels(px, 0, w, 0, 0, w, h)
    val out = ByteArray(rb * h)
    for (y in 0 until h) for (x in 0 until w) {
        val c = px[y * w + x]
        val l = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
        if (l < threshold) {
            val i = y * rb + (x shr 3)
            out[i] = (out[i].toInt() or (0x80 shr (x and 7))).toByte()
        }
    }
    return Mono(w, h, out)
}

object Dither {
    private val BAYER = intArrayOf(0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5)

    /** [g] is grayscale 0..255 (modified in place). Returns true where the pixel should print black. */
    fun run(g: FloatArray, w: Int, h: Int, mode: String): BooleanArray {
        val out = BooleanArray(w * h)
        when (mode) {
            "thresh" -> for (i in g.indices) out[i] = g[i] < 128f
            "bayer" -> for (y in 0 until h) for (x in 0 until w) {
                val t = (BAYER[(y and 3) * 4 + (x and 3)] + 0.5f) * 255f / 16f
                out[y * w + x] = g[y * w + x] < t
            }
            "atkinson" -> for (y in 0 until h) for (x in 0 until w) {
                val i = y * w + x
                val old = g[i]
                val nw = if (old < 128f) 0f else 255f
                out[i] = nw == 0f
                val e = (old - nw) / 8f
                if (x + 1 < w) g[i + 1] += e
                if (x + 2 < w) g[i + 2] += e
                if (y + 1 < h) {
                    if (x > 0) g[i + w - 1] += e
                    g[i + w] += e
                    if (x + 1 < w) g[i + w + 1] += e
                }
                if (y + 2 < h) g[i + 2 * w] += e
            }
            else -> for (y in 0 until h) for (x in 0 until w) {
                val i = y * w + x
                val old = g[i]
                val nw = if (old < 128f) 0f else 255f
                out[i] = nw == 0f
                val e = old - nw
                if (x + 1 < w) g[i + 1] += e * 7f / 16f
                if (y + 1 < h) {
                    if (x > 0) g[i + w - 1] += e * 3f / 16f
                    g[i + w] += e * 5f / 16f
                    if (x + 1 < w) g[i + w + 1] += e / 16f
                }
            }
        }
        return out
    }
}

class Renderer(private val fonts: Fonts) {
    private class Row(val h: Int, val draw: (Canvas, Float) -> Unit)

    private var cKey = ""
    private var cBmp: Bitmap? = null

    /** Renders a doc to a white ARGB bitmap [w] pixels wide (what you see is what prints after 1-bit conversion). */
    @Synchronized
    fun render(doc: Doc, w: Int): Bitmap =
        if (doc.type == DocType.IMAGE) image(doc, w) else text(doc, w)

    private fun paint(font: String, bold: Boolean, size: Float) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = fonts.typeface(font, bold)
        textSize = size
        color = Color.BLACK
    }

    private fun layout(s: CharSequence, p: TextPaint, width: Int, a: Layout.Alignment): StaticLayout =
        StaticLayout.Builder.obtain(s, 0, s.length, p, width.coerceAtLeast(16))
            .setAlignment(a)
            .setIncludePad(false)
            .build()

    // ---------- notes & lists ----------

    private fun text(doc: Doc, w: Int): Bitmap {
        val m = 6f
        val cw = w - 12
        val size = doc.size.toFloat()
        val fill = Paint().apply { color = Color.BLACK; isAntiAlias = true }
        val stroke = Paint(fill).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f }
        val al = when (doc.align) {
            1 -> Layout.Alignment.ALIGN_CENTER
            2 -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        val rows = ArrayList<Row>()

        fun block(s: CharSequence, p: TextPaint, a: Layout.Alignment, after: Int) {
            val l = layout(s, p, cw, a)
            rows.add(Row(l.height + after) { c, y ->
                c.save(); c.translate(m, y); l.draw(c); c.restore()
            })
        }

        val hasHead = doc.title.isNotBlank() || doc.showDate
        if (doc.title.isNotBlank()) block(doc.title.trim(), paint(doc.font, true, size * 1.35f), al, 4)
        if (doc.showDate) {
            val d = SimpleDateFormat("EEE d MMM yyyy  HH:mm", Locale.getDefault()).format(Date())
            block(d, paint(doc.font, false, size * 0.6f), al, 4)
        }
        if (hasHead) rows.add(Row(10) { c, y -> c.drawRect(m, y + 3f, w - m, y + 5f, fill) })

        if (doc.type == DocType.NOTE) {
            if (doc.body.isNotBlank()) block(doc.body.trimEnd(), paint(doc.font, doc.bold, size), al, 0)
        } else {
            val body = paint(doc.font, doc.bold, size)
            val headP = paint(doc.font, true, size * 1.1f)
            val style = doc.listStyle
            val gap = (size * (if (style == "box") 0.5f else 0.3f)).toInt()
            val box = size * 0.85f
            var n = 0
            for (raw in doc.body.split("\n")) {
                val line = raw.trimEnd('\r')
                if (line.startsWith("# ")) {
                    n = 0
                    val l = layout(line.substring(2), headP, cw, Layout.Alignment.ALIGN_NORMAL)
                    rows.add(Row(gap + l.height + 8) { c, y ->
                        c.save(); c.translate(m, y + gap); l.draw(c); c.restore()
                        c.drawRect(m, y + gap + l.height + 3f, w - m, y + gap + l.height + 5f, fill)
                    })
                    continue
                }
                n++
                val num = n
                val pw = when (style) {
                    "box" -> (box + size * 0.45f).toInt()
                    "bullet", "dash" -> (size * 0.9f).toInt()
                    "number" -> (body.measureText("99.") + size * 0.3f).toInt()
                    else -> 0
                }
                val l = layout(line, body, cw - pw, Layout.Alignment.ALIGN_NORMAL)
                val first = l.getLineBottom(0)
                val minH = when (style) {
                    "ruled" -> (size * 1.5f).toInt()
                    "box" -> box.toInt()
                    else -> 0
                }
                val h = max(l.height, minH) + gap
                rows.add(Row(h) { c, y ->
                    val top = y + gap / 2f
                    val mid = top + first / 2f
                    when (style) {
                        "box" -> c.drawRect(m + 1.5f, mid - box / 2f, m + box - 1.5f, mid + box / 2f, stroke)
                        "bullet" -> c.drawCircle(m + size * 0.25f, mid, size * 0.13f, fill)
                        "dash" -> c.drawRect(m, mid - 1.5f, m + size * 0.5f, mid + 1.5f, fill)
                        "number" -> c.drawText("$num.", m, top - body.ascent(), body)
                    }
                    c.save(); c.translate(m + pw, top); l.draw(c); c.restore()
                    if (style == "ruled" || (line.isBlank() && style != "plain")) {
                        c.drawRect(m + pw, y + h - 2f, w - m, y + h - 0.5f, fill)
                    }
                })
            }
        }

        if (rows.isEmpty()) rows.add(Row(40) { _, _ -> })
        val pad = 6
        val total = rows.sumOf { it.h } + pad * 2
        val bmp = Bitmap.createBitmap(w, total, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawColor(Color.WHITE)
        var y = pad.toFloat()
        for (r in rows) {
            r.draw(cv, y)
            y += r.h
        }
        return bmp
    }

    // ---------- images ----------

    private fun scaledSource(doc: Doc, w: Int): Bitmap? {
        val path = doc.imagePath ?: return null
        val key = "$path|$w|${doc.rotation}"
        if (key == cKey && cBmp != null) return cBmp

        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        if (o.outWidth <= 0) return null
        var s = 1
        while (o.outWidth / (s * 2) >= w && o.outHeight / (s * 2) >= w) s *= 2
        var b = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null

        val exif = runCatching {
            ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val base = when (exif) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
        val deg = (base + doc.rotation) % 360
        if (deg != 0) {
            b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg.toFloat()) }, true)
        }
        val nh = max(1, (b.height * w.toFloat() / b.width).roundToInt())
        b = Bitmap.createScaledBitmap(b, w, nh, true)
        cKey = key
        cBmp = b
        return b
    }

    private fun image(doc: Doc, w: Int): Bitmap {
        val src = scaledSource(doc, w)
            ?: return Bitmap.createBitmap(w, 60, Bitmap.Config.ARGB_8888).also { Canvas(it).drawColor(Color.WHITE) }
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val cf = if (doc.contrast >= 0) 1f + doc.contrast / 25f else 1f + doc.contrast / 100f
        val g = FloatArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            val a = Color.alpha(c)
            var v = Color.red(c) * 0.299f + Color.green(c) * 0.587f + Color.blue(c) * 0.114f
            v = (v * a + 255f * (255 - a)) / 255f          // transparent -> white
            v = (v - 128f) * cf + 128f + doc.brightness * 1.5f
            g[i] = v.coerceIn(0f, 255f)
        }
        val black = Dither.run(g, w, h, doc.dither)
        val out = IntArray(w * h) { if (black[it] != doc.invert) Color.BLACK else Color.WHITE }
        val img = Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)

        val cap = doc.body.trim()
        if (cap.isEmpty()) return img
        val lay = layout(cap, paint(doc.font, doc.bold, doc.size.toFloat()), w - 12, Layout.Alignment.ALIGN_CENTER)
        val res = Bitmap.createBitmap(w, h + lay.height + 20, Bitmap.Config.ARGB_8888)
        val cv = Canvas(res)
        cv.drawColor(Color.WHITE)
        cv.drawBitmap(img, 0f, 0f, null)
        cv.translate(6f, h + 10f)
        lay.draw(cv)
        return res
    }
}
