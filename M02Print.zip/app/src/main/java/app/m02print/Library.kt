package app.m02print

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Net {
    private const val UA = "M02Print/1.0 (Android app for a Phomemo M02 thermal printer)"

    fun bytes(url: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA)
        c.connectTimeout = 15000
        c.readTimeout = 30000
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    fun text(url: String): String = String(bytes(url), Charsets.UTF_8)
}

/** [sources] are download URLs in priority order; the first is also used as the grid thumbnail. */
data class LibImage(
    val id: String,
    val title: String,
    val sources: List<String>,
    val creator: String,
    val license: String
)

private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k)
private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

object ImageSearch {
    val SOURCES = listOf("commons" to "Wikimedia Commons", "openverse" to "Openverse")
    val KINDS = listOf("any" to "Any", "draw" to "Drawings", "photo" to "Photos")
    val IDEAS = listOf("line art", "icon", "silhouette", "doodle", "flower", "cat", "map", "mandala", "stamp", "vintage")

    suspend fun search(source: String, q: String, kind: String): List<LibImage> =
        withContext(Dispatchers.IO) {
            if (q.isBlank()) emptyList()
            else if (source == "openverse") openverse(q, kind) else commons(q, kind)
        }

    private fun commons(q: String, kind: String): List<LibImage> {
        val filter = when (kind) {
            "draw" -> "filetype:drawing"
            "photo" -> "filetype:bitmap"
            else -> "filetype:bitmap|drawing"
        }
        val url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search" +
            "&gsrnamespace=6&gsrlimit=30&gsrsearch=" + enc("$q $filter") +
            "&prop=imageinfo&iiprop=url%7Cextmetadata&iiurlwidth=640&iiextmetadatafilter=Artist%7CLicenseShortName"
        val pages = JSONObject(Net.text(url)).optJSONObject("query")?.optJSONObject("pages")
            ?: return emptyList()
        val out = ArrayList<Pair<Int, LibImage>>()
        for (k in pages.keys()) {
            val p = pages.getJSONObject(k)
            val ii = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
            val thumb = ii.str("thumburl").ifEmpty { ii.str("url") }
            if (thumb.isEmpty()) continue
            val meta = ii.optJSONObject("extmetadata")
            val artist = meta?.optJSONObject("Artist")?.str("value").orEmpty()
                .replace(Regex("<[^>]*>"), "").trim()
            val lic = meta?.optJSONObject("LicenseShortName")?.str("value").orEmpty()
            val title = p.str("title").removePrefix("File:").substringBeforeLast('.')
            out.add(p.optInt("index") to LibImage("c$k", title, listOf(thumb), artist, lic))
        }
        return out.sortedBy { it.first }.map { it.second }
    }

    private fun openverse(q: String, kind: String): List<LibImage> {
        val cat = when (kind) {
            "draw" -> "&category=illustration"
            "photo" -> "&category=photograph"
            else -> ""
        }
        val root = JSONObject(Net.text("https://api.openverse.org/v1/images/?q=${enc(q)}&page_size=20&mature=false$cat"))
        val a = root.optJSONArray("results") ?: return emptyList()
        val out = ArrayList<LibImage>()
        for (i in 0 until a.length()) {
            val r = a.getJSONObject(i)
            val src = listOf(r.str("thumbnail"), r.str("url")).filter { it.isNotEmpty() }
            if (src.isEmpty()) continue
            val lic = (r.str("license") + " " + r.str("license_version")).uppercase().trim()
            out.add(LibImage("o" + r.str("id"), r.str("title"), src, r.str("creator"), lic))
        }
        return out
    }
}

/** Tiny in-memory thumbnail cache + downsampling loader. */
object ThumbCache {
    private val cache = LruCache<String, Bitmap>(40)

    suspend fun get(url: String): Bitmap? {
        cache.get(url)?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching {
                val b = Net.bytes(url)
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(b, 0, b.size, o)
                var s = 1
                while (o.outWidth / (s * 2) >= 360) s *= 2
                BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
            }.getOrNull()?.also { cache.put(url, it) }
        }
    }
}
