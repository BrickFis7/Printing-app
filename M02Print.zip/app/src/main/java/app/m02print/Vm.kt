package app.m02print

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

sealed interface Screen {
    data object Home : Screen
    data class Edit(val id: String) : Screen
    data object Library : Screen
    data object Settings : Screen
}

class AppVm(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val store = DocStore(ctx)
    private val imgDir = File(ctx.filesDir, "img").apply { mkdirs() }

    val prefs = Prefs(ctx)
    val fonts = Fonts(ctx)
    val renderer = Renderer(fonts)
    val printer = PrinterManager(ctx)

    val docs = mutableStateListOf<Doc>()
    var screen by mutableStateOf<Screen>(Screen.Home)
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
    var btOk by mutableStateOf(false)

    val found = mutableStateListOf<Found>()
    var scanning by mutableStateOf(false)
    private var stopScanFn: (() -> Unit)? = null

    // Hooks set by MainActivity (permission + file pickers)
    var requestBt: () -> Unit = {}
    var pickPhoto: () -> Unit = {}
    var pickFont: () -> Unit = {}

    init {
        docs.addAll(store.load().sortedByDescending { it.updated })
    }

    // ---------- documents ----------

    private fun persist() = store.save(docs.toList())

    fun get(id: String): Doc? = docs.firstOrNull { it.id == id }

    fun upsert(d: Doc) {
        val nd = d.copy(updated = System.currentTimeMillis())
        val i = docs.indexOfFirst { it.id == d.id }
        if (i >= 0) docs[i] = nd else docs.add(0, nd)
        persist()
    }

    fun create(type: DocType, t: Template? = null) {
        val d = if (t != null) {
            Doc(type = DocType.LIST, title = t.title, body = t.body, listStyle = t.style, showDate = t.date)
        } else {
            Doc(type = type)
        }
        upsert(d)
        screen = Screen.Edit(d.id)
    }

    fun remove(id: String) {
        val d = get(id)
        docs.removeAll { it.id == id }
        d?.imagePath?.let { File(it).delete() }
        persist()
    }

    fun closeEditor(d: Doc) {
        val empty = d.type == DocType.NOTE && d.title.isBlank() && d.body.isBlank()
        if (empty) remove(d.id) else upsert(d)
        screen = Screen.Home
    }

    // ---------- images & fonts ----------

    fun importImage(uri: Uri) {
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) {
                runCatching {
                    val f = File(imgDir, UUID.randomUUID().toString() + ".img")
                    ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    f.absolutePath
                }.getOrNull()
            }
            if (path == null) {
                message = "Couldn't read that image"
                return@launch
            }
            val d = Doc(type = DocType.IMAGE, title = "Photo", imagePath = path)
            upsert(d)
            screen = Screen.Edit(d.id)
        }
    }

    fun useImage(img: LibImage, credit: Boolean) {
        busy = true
        message = "Downloading…"
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) {
                runCatching {
                    var data: ByteArray? = null
                    for (u in img.sources) {
                        data = runCatching { Net.bytes(u) }.getOrNull()
                        if (data != null) break
                    }
                    val f = File(imgDir, UUID.randomUUID().toString() + ".img")
                    f.writeBytes(data ?: error("no data"))
                    f.absolutePath
                }.getOrNull()
            }
            busy = false
            if (path == null) {
                message = "Download failed"
                return@launch
            }
            message = null
            val cap = if (credit) listOf(img.creator, img.license).filter { it.isNotBlank() }.joinToString(" · ") else ""
            val d = Doc(
                type = DocType.IMAGE, title = img.title.take(40), imagePath = path,
                body = cap, size = 18, align = 1
            )
            upsert(d)
            screen = Screen.Edit(d.id)
        }
    }

    fun importFont(uri: Uri) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { fonts.import(uri) }
            fonts.bump()
            message = if (ok) "Font added" else "Couldn't add that font"
        }
    }

    // ---------- printer ----------

    fun bonded(): List<Found> = if (btOk) printer.bonded() else emptyList()

    fun choose(f: Found) {
        prefs.printerAddr = f.addr
        prefs.printerName = f.name
        prefs.ble = false
        prefs.save()
        message = "Printer set: ${f.name}"
    }

    fun startScan() {
        if (!btOk) {
            requestBt()
            return
        }
        stopScan()
        found.clear()
        scanning = true
        stopScanFn = printer.scan { f ->
            if (found.none { it.addr == f.addr }) found.add(f)
        }
        viewModelScope.launch {
            delay(12000)
            stopScan()
        }
    }

    fun stopScan() {
        stopScanFn?.invoke()
        stopScanFn = null
        scanning = false
    }

    fun print(d: Doc, copies: Int = 1) {
        val addr = prefs.printerAddr
        if (addr == null) {
            message = "Choose your printer first"
            screen = Screen.Settings
            return
        }
        if (!btOk) {
            requestBt()
            return
        }
        if (busy) return
        busy = true
        message = "Printing…"
        viewModelScope.launch {
            try {
                val bytes = withContext(Dispatchers.Default) {
                    val mono = renderer.render(d, prefs.width).toMono()
                    M02.job(mono, prefs.density, prefs.tail, copies)
                }
                val usedBle = printer.send(addr, bytes, prefs.ble).getOrThrow()
                if (usedBle != prefs.ble) {
                    prefs.ble = usedBle
                    prefs.save()
                }
                message = "Sent to printer ✓"
            } catch (e: Exception) {
                message = "Print failed: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    fun testPrint() = print(
        Doc(type = DocType.NOTE, title = "M02 Print", body = "Printer test\nAa Bb Cc 0123456789", align = 1, showDate = true)
    )
}
