package app.m02print

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import java.io.File

/** Saves all docs as one small JSON file. */
class DocStore(ctx: Context) {
    private val file = File(ctx.filesDir, "docs.json")

    fun load(): List<Doc> = runCatching {
        val a = JSONArray(file.readText())
        List(a.length()) { Doc.fromJson(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    fun save(docs: List<Doc>) {
        runCatching {
            val a = JSONArray()
            docs.forEach { a.put(it.toJson()) }
            file.writeText(a.toString())
        }
    }
}

/** App settings. Compose-observable; call [save] to persist. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("m02", Context.MODE_PRIVATE)

    var printerAddr by mutableStateOf<String?>(sp.getString("addr", null))
    var printerName by mutableStateOf<String?>(sp.getString("name", null))
    var width by mutableIntStateOf(sp.getInt("width", 384))
    var density by mutableIntStateOf(sp.getInt("density", 4))
    var tail by mutableIntStateOf(sp.getInt("tail", 80))
    var speed by mutableIntStateOf(sp.getInt("speed", 50))   // rows per second we feed the printer
    var ble: Boolean = sp.getBoolean("ble", false)   // remembers which link worked last

    fun save() {
        sp.edit()
            .putString("addr", printerAddr)
            .putString("name", printerName)
            .putInt("width", width)
            .putInt("density", density)
            .putInt("tail", tail)
            .putInt("speed", speed)
            .putBoolean("ble", ble)
            .apply()
    }
}

/** Built-in system fonts plus any .ttf/.otf the user imported. */
class Fonts(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "fonts").apply { mkdirs() }
    private val cache = HashMap<String, Typeface>()

    /** Bumped whenever the custom font list changes so the UI refreshes. */
    var customVersion by mutableIntStateOf(0)

    fun custom(): List<FontDef> =
        dir.listFiles()?.filter { it.isFile }?.sortedBy { it.name }
            ?.map { FontDef("custom:" + it.name, it.nameWithoutExtension) }.orEmpty()

    fun all(): List<FontDef> = BUILTIN_FONTS + custom()

    @Synchronized
    fun typeface(id: String, bold: Boolean): Typeface {
        val key = "$id/$bold"
        return cache.getOrPut(key) {
            if (id.startsWith("custom:")) {
                val base = runCatching { Typeface.createFromFile(File(dir, id.removePrefix("custom:"))) }
                    .getOrNull() ?: Typeface.DEFAULT
                if (bold) Typeface.create(base, Typeface.BOLD) else base
            } else {
                val fam = BUILTIN_FONTS.firstOrNull { it.id == id }?.family ?: "sans-serif"
                Typeface.create(fam, if (bold) Typeface.BOLD else Typeface.NORMAL)
            }
        }
    }

    fun import(uri: Uri): Boolean = runCatching {
        var name = "font_${System.currentTimeMillis()}.ttf"
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { name = it }
        }
        name = name.replace(Regex("[^A-Za-z0-9._ -]"), "_")
        val f = File(dir, name)
        ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        true
    }.getOrDefault(false)

    @Synchronized
    fun remove(def: FontDef) {
        File(dir, def.id.removePrefix("custom:")).delete()
        cache.keys.removeAll { it.startsWith(def.id + "/") }
        customVersion++
    }

    fun bump() { customVersion++ }
}
