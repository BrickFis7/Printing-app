@file:OptIn(ExperimentalMaterial3Api::class)

package app.m02print

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

// ---------------------------------------------------------------- image library

@Composable
fun LibraryScreen(vm: AppVm) {
    val scope = rememberCoroutineScope()
    val kb = LocalSoftwareKeyboardController.current
    var q by remember { mutableStateOf("line art") }
    var source by remember { mutableStateOf("commons") }
    var kind by remember { mutableStateOf("any") }
    var results by remember { mutableStateOf<List<LibImage>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var picked by remember { mutableStateOf<LibImage?>(null) }

    BackHandler { vm.screen = Screen.Home }

    fun search() {
        kb?.hide()
        loading = true
        error = null
        val src = source
        val kd = kind
        val query = q.trim()
        scope.launch {
            try {
                results = ImageSearch.search(src, query, kd)
            } catch (e: Exception) {
                results = emptyList()
                error = "Search failed: ${e.message ?: "no connection"}"
            }
            loading = false
        }
    }

    LaunchedEffect(source, kind) { search() }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Free image library") },
                navigationIcon = {
                    IconButton(onClick = { vm.screen = Screen.Home }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                singleLine = true,
                label = { Text("Search") },
                trailingIcon = { IconButton(onClick = { search() }) { Icon(Icons.Default.Search, "Search") } },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { search() }),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            )
            Chips(ImageSearch.SOURCES, source, Modifier.padding(horizontal = 12.dp)) { source = it }
            Chips(ImageSearch.KINDS, kind, Modifier.padding(horizontal = 12.dp)) { kind = it }
            Chips(ImageSearch.IDEAS.map { it to it }, "", Modifier.padding(horizontal = 12.dp)) { q = it; search() }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                    error != null -> Text(
                        error ?: "",
                        Modifier.align(Alignment.Center).padding(24.dp),
                        color = MaterialTheme.colorScheme.error
                    )
                    results.isEmpty() -> Text(
                        "No results. Try another word or source.",
                        Modifier.align(Alignment.Center).padding(24.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    else -> LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        contentPadding = PaddingValues(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(results, key = { it.id }) { img ->
                            Box(Modifier.aspectRatio(1f).background(Color.White).clickable { picked = img }) {
                                NetImage(img.sources.first(), Modifier.fillMaxSize(), ContentScale.Fit)
                            }
                        }
                    }
                }
            }
        }
    }

    picked?.let { img ->
        var credit by remember(img) { mutableStateOf(false) }
        val byLine = if (img.creator.isBlank()) "Unknown author" else "By " + img.creator
        AlertDialog(
            onDismissRequest = { picked = null },
            title = { Text(img.title.ifBlank { "Image" }, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.fillMaxWidth().height(220.dp).background(Color.White)) {
                        NetImage(img.sources.first(), Modifier.fillMaxSize(), ContentScale.Fit)
                    }
                    Text(byLine + (if (img.license.isBlank()) "" else " · " + img.license), style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.clickable { credit = !credit }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = credit, onCheckedChange = { credit = it })
                        Text("Print credit line under the image", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            },
            confirmButton = { Button(onClick = { picked = null; vm.useImage(img, credit) }) { Text("Use image") } },
            dismissButton = { TextButton(onClick = { picked = null }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- settings

@Composable
private fun SectionTitle(t: String) {
    Text(t, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun DeviceRow(f: Found, selected: Boolean, onPick: () -> Unit) {
    Card(
        onClick = onPick,
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.secondaryContainer
            else MaterialTheme.colorScheme.surfaceContainerHigh
        )
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(f.name, fontWeight = FontWeight.SemiBold)
                Text(f.addr, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (selected) Icon(Icons.Default.Check, "Selected")
        }
    }
}

@Composable
fun SettingsScreen(vm: AppVm) {
    val ctx = LocalContext.current
    var bonded by remember { mutableStateOf(vm.bonded()) }
    LaunchedEffect(vm.btOk) { bonded = vm.bonded() }
    DisposableEffect(Unit) { onDispose { vm.stopScan() } }
    BackHandler { vm.screen = Screen.Home }
    val custom = remember(vm.fonts.customVersion) { vm.fonts.custom() }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Printer & settings") },
                navigationIcon = {
                    IconButton(onClick = { vm.screen = Screen.Home }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SectionTitle("Printer")
            Text("Selected: ${vm.prefs.printerName ?: "none"}")
            if (!vm.btOk) {
                Button(onClick = { vm.requestBt() }) { Text("Allow Bluetooth access") }
            }

            Text("Paired devices", style = MaterialTheme.typography.labelLarge)
            if (bonded.isEmpty()) {
                Text(
                    "None yet. Switch the M02 on, then pair it in Android's Bluetooth settings.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            bonded.forEach { f -> DeviceRow(f, f.addr == vm.prefs.printerAddr) { vm.choose(f) } }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
                }) { Text("Bluetooth settings") }
                OutlinedButton(onClick = { bonded = vm.bonded(); vm.startScan() }) {
                    Text(if (vm.scanning) "Scanning…" else "Scan nearby")
                }
            }
            vm.found.forEach { f -> DeviceRow(f, f.addr == vm.prefs.printerAddr) { vm.choose(f) } }

            Button(onClick = { vm.testPrint() }, enabled = !vm.busy && vm.prefs.printerAddr != null) {
                Text("Print test page")
            }

            SectionTitle("Printing")
            Text("Print width", style = MaterialTheme.typography.labelMedium)
            Chips(
                listOf("384" to "384 px · M02 / T02", "576" to "576 px · M02S / Pro"),
                vm.prefs.width.toString()
            ) { vm.prefs.width = it.toInt(); vm.prefs.save() }
            SliderRow(
                "Darkness  ${vm.prefs.density}  (default 4)",
                vm.prefs.density.toFloat(), 1f..8f, steps = 6, onDone = { vm.prefs.save() }
            ) { vm.prefs.density = it.roundToInt() }
            SliderRow(
                "Send speed  ${vm.prefs.speed} rows/s",
                vm.prefs.speed.toFloat(), 15f..300f, onDone = { vm.prefs.save() }
            ) { vm.prefs.speed = it.roundToInt() }
            Text(
                "Lower this if a print stops partway. Raise it for faster printing once it works.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            SliderRow(
                "Extra paper after each print  ${vm.prefs.tail}",
                vm.prefs.tail.toFloat(), 0f..240f, onDone = { vm.prefs.save() }
            ) { vm.prefs.tail = it.roundToInt() }

            SectionTitle("Fonts")
            Text(
                "Ten system fonts are built in. Add your own .ttf or .otf files for more.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            custom.forEach { f ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(f.label, Modifier.weight(1f))
                    TextButton(onClick = { vm.fonts.remove(f) }) { Text("Remove") }
                }
            }
            OutlinedButton(onClick = { vm.pickFont() }) { Text("Add font file") }

            SectionTitle("About")
            Text(
                "Image search uses Wikimedia Commons and Openverse. Many images need attribution; " +
                    "tick “Print credit line” when you pick one, and check each licence before sharing prints.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
