@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package app.m02print

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun App(vm: AppVm) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        when (val s = vm.screen) {
            Screen.Home -> HomeScreen(vm)
            is Screen.Edit -> {
                val d = vm.get(s.id)
                key(s.id) {
                    if (d == null) {
                        LaunchedEffect(Unit) { vm.screen = Screen.Home }
                    } else if (d.type == DocType.IMAGE) {
                        ImageEditor(vm, d)
                    } else {
                        TextEditor(vm, d)
                    }
                }
            }
            Screen.Library -> LibraryScreen(vm)
            Screen.Settings -> SettingsScreen(vm)
        }

        val msg = vm.message
        if (msg != null) {
            LaunchedEffect(msg, vm.busy) {
                if (!vm.busy) {
                    delay(if (msg.startsWith("Print failed")) 7000 else 2500)
                    vm.message = null
                }
            }
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(start = 16.dp, end = 16.dp, bottom = 96.dp),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.inverseSurface,
                contentColor = MaterialTheme.colorScheme.inverseOnSurface,
                shadowElevation = 6.dp
            ) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (vm.busy) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = LocalContentColor.current)
                        Spacer(Modifier.width(10.dp))
                    }
                    Text(msg)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Home

@Composable
fun HomeScreen(vm: AppVm) {
    var sheet by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf<Doc?>(null) }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("M02 Print", fontWeight = FontWeight.Bold) },
                actions = {
                    AssistChip(
                        onClick = { vm.screen = Screen.Settings },
                        label = { Text(vm.prefs.printerName ?: "Choose printer", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        modifier = Modifier.widthIn(max = 170.dp)
                    )
                    IconButton(onClick = { vm.screen = Screen.Settings }) { Icon(Icons.Default.Settings, "Settings") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { sheet = true }) { Icon(Icons.Default.Add, "New") }
        }
    ) { pad ->
        if (vm.docs.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad).padding(32.dp), Alignment.Center) {
                Text(
                    "Nothing saved yet.\nTap + to write a note, make a list, or print a picture.",
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(pad),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(vm.docs, key = { it.id }) { d -> DocCard(vm, d) { del = d } }
            }
        }
    }

    if (sheet) NewSheet(vm) { sheet = false }

    del?.let { d ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("Delete this item?") },
            text = { Text(docName(d)) },
            confirmButton = { TextButton(onClick = { vm.remove(d.id); del = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("Keep") } }
        )
    }
}

private fun docName(d: Doc): String =
    d.title.ifBlank {
        d.body.lineSequence().map { it.removePrefix("# ").trim() }.firstOrNull { it.isNotEmpty() } ?: "Untitled"
    }

@Composable
fun DocCard(vm: AppVm, d: Doc, onDelete: () -> Unit) {
    val sub = when (d.type) {
        DocType.NOTE -> "Note"
        DocType.LIST -> "List · " + (LIST_STYLES.firstOrNull { it.first == d.listStyle }?.second ?: "")
        DocType.IMAGE -> "Image · " + (DITHERS.firstOrNull { it.first == d.dither }?.second ?: "")
    }
    Card(
        onClick = { vm.screen = Screen.Edit(d.id) },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
    ) {
        Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(docName(d), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledTonalButton(onClick = { vm.print(d) }, enabled = !vm.busy) { Text("Print") }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete") }
        }
    }
}

@Composable
fun NewSheet(vm: AppVm, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.padding(start = 16.dp, end = 16.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("New", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onDismiss(); vm.create(DocType.NOTE) }, modifier = Modifier.weight(1f)) { Text("Note") }
                Button(onClick = { onDismiss(); vm.pickPhoto() }, modifier = Modifier.weight(1f)) { Text("Photo") }
                Button(onClick = { onDismiss(); vm.screen = Screen.Library }, modifier = Modifier.weight(1f)) { Text("Library") }
            }
            Text("Lists", style = MaterialTheme.typography.titleMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TEMPLATES.forEach { t ->
                    AssistChip(onClick = { onDismiss(); vm.create(DocType.LIST, t) }, label = { Text(t.name) })
                }
            }
        }
    }
}

// ---------------------------------------------------------------- shared widgets

@Composable
fun Chips(
    options: List<Pair<String, String>>,
    selected: String,
    modifier: Modifier = Modifier,
    onPick: (String) -> Unit
) {
    Row(modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (id, label) ->
            FilterChip(selected = id == selected, onClick = { onPick(id) }, label = { Text(label) })
        }
    }
}

@Composable
fun FontRow(vm: AppVm, selected: String, onPick: (String) -> Unit) {
    val list = remember(vm.fonts.customVersion) { vm.fonts.all() }
    Column {
        Text("Font", style = MaterialTheme.typography.labelMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            list.forEach { f ->
                FilterChip(
                    selected = f.id == selected,
                    onClick = { onPick(f.id) },
                    label = { Text(f.label, fontFamily = FontFamily(vm.fonts.typeface(f.id, false)), fontSize = 16.sp) }
                )
            }
        }
    }
}

@Composable
fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    onDone: () -> Unit = {},
    onChange: (Float) -> Unit
) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps, onValueChangeFinished = onDone)
    }
}

@Composable
fun rememberPreview(vm: AppVm, d: Doc): State<Bitmap?> =
    produceState<Bitmap?>(null, d, vm.prefs.width) {
        delay(120)
        value = withContext(Dispatchers.Default) {
            vm.renderer.render(d, vm.prefs.width).toMono().toBitmap()
        }
    }

@Composable
fun Paper(bmp: Bitmap?) {
    Surface(
        modifier = Modifier.widthIn(max = 440.dp).fillMaxWidth(),
        color = Color.White,
        shadowElevation = 4.dp,
        shape = RoundedCornerShape(2.dp)
    ) {
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = "Print preview",
                modifier = Modifier.fillMaxWidth(),
                contentScale = ContentScale.FillWidth,
                filterQuality = FilterQuality.None
            )
        } else {
            Box(Modifier.fillMaxWidth().height(120.dp), Alignment.Center) { CircularProgressIndicator() }
        }
    }
}

@Composable
fun NetImage(url: String, modifier: Modifier = Modifier, scale: ContentScale = ContentScale.Fit) {
    val st by produceState(Pair<Bitmap?, Boolean>(null, false), url) { value = ThumbCache.get(url) to true }
    val b = st.first
    if (b != null) {
        Image(bitmap = b.asImageBitmap(), contentDescription = null, modifier = modifier, contentScale = scale)
    } else {
        Box(modifier, Alignment.Center) {
            if (!st.second) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            else Text("×", color = MaterialTheme.colorScheme.outline)
        }
    }
}
