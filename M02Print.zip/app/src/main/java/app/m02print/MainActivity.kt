package app.m02print

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: AppVm by viewModels()

    private val btLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.btOk = hasBt()
    }
    private val photoLauncher = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importImage(uri)
    }
    private val fontLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importFont(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm.requestBt = { btLauncher.launch(btPerms()) }
        vm.pickPhoto = {
            photoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        vm.pickFont = { fontLauncher.launch(arrayOf("*/*")) }
        vm.btOk = hasBt()
        if (!vm.btOk) vm.requestBt()
        setContent { M02Theme { App(vm) } }
    }

    override fun onResume() {
        super.onResume()
        vm.btOk = hasBt()
    }

    private fun btPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    private fun hasBt(): Boolean = btPerms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }
}
