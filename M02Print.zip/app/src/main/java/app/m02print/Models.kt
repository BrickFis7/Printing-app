package app.m02print

import org.json.JSONObject
import java.util.UUID

enum class DocType { NOTE, LIST, IMAGE }

/** One saved thing: a note, a list or an image. Lists/notes use [body]; images use [imagePath] ([body] = caption). */
data class Doc(
    val id: String = UUID.randomUUID().toString(),
    val type: DocType = DocType.NOTE,
    val title: String = "",
    val body: String = "",
    val font: String = "sans",
    val size: Int = 28,
    val bold: Boolean = false,
    val align: Int = 0,               // 0 left, 1 center, 2 right
    val listStyle: String = "box",
    val showDate: Boolean = false,
    val imagePath: String? = null,
    val dither: String = "floyd",
    val brightness: Int = 0,
    val contrast: Int = 0,
    val rotation: Int = 0,
    val invert: Boolean = false,
    val updated: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("type", type.name); put("title", title); put("body", body)
        put("font", font); put("size", size); put("bold", bold); put("align", align)
        put("listStyle", listStyle); put("showDate", showDate)
        put("imagePath", imagePath ?: JSONObject.NULL)
        put("dither", dither); put("brightness", brightness); put("contrast", contrast)
        put("rotation", rotation); put("invert", invert); put("updated", updated)
    }

    companion object {
        fun fromJson(o: JSONObject): Doc = Doc(
            id = o.getString("id"),
            type = runCatching { DocType.valueOf(o.getString("type")) }.getOrDefault(DocType.NOTE),
            title = o.optString("title"),
            body = o.optString("body"),
            font = o.optString("font", "sans"),
            size = o.optInt("size", 28),
            bold = o.optBoolean("bold"),
            align = o.optInt("align"),
            listStyle = o.optString("listStyle", "box"),
            showDate = o.optBoolean("showDate"),
            imagePath = if (o.isNull("imagePath")) null else o.getString("imagePath"),
            dither = o.optString("dither", "floyd"),
            brightness = o.optInt("brightness"),
            contrast = o.optInt("contrast"),
            rotation = o.optInt("rotation"),
            invert = o.optBoolean("invert"),
            updated = o.optLong("updated")
        )
    }
}

val LIST_STYLES = listOf(
    "box" to "Boxes", "bullet" to "Bullets", "number" to "Numbers",
    "dash" to "Dashes", "ruled" to "Ruled lines", "plain" to "Plain"
)
val DITHERS = listOf(
    "floyd" to "Smooth", "atkinson" to "Crisp", "bayer" to "Pattern", "thresh" to "Pure B/W"
)
val ALIGNS = listOf("0" to "Left", "1" to "Center", "2" to "Right")

/** [family] is an Android system font family name; custom fonts have id "custom:<file>". */
data class FontDef(val id: String, val label: String, val family: String? = null)

val BUILTIN_FONTS = listOf(
    FontDef("sans", "Sans", "sans-serif"),
    FontDef("light", "Light", "sans-serif-light"),
    FontDef("cond", "Condensed", "sans-serif-condensed"),
    FontDef("black", "Heavy", "sans-serif-black"),
    FontDef("serif", "Serif", "serif"),
    FontDef("mono", "Mono", "monospace"),
    FontDef("typewriter", "Typewriter", "serif-monospace"),
    FontDef("hand", "Handwriting", "cursive"),
    FontDef("casual", "Casual", "casual"),
    FontDef("caps", "Small caps", "sans-serif-smallcaps")
)

data class Template(
    val name: String,
    val title: String,
    val style: String,
    val body: String,
    val date: Boolean = false
)

private fun blanks(n: Int) = List(n) { "" }.joinToString("\n")
private fun sec(title: String, n: Int) = "# $title\n" + blanks(n)

val TEMPLATES = listOf(
    Template("Checklist", "Checklist", "box", blanks(8)),
    Template("To-do", "To-do", "box", listOf(sec("Important", 3), sec("Later", 4)).joinToString("\n"), true),
    Template(
        "Shopping", "Shopping", "box",
        listOf(sec("Produce", 3), sec("Dairy & eggs", 2), sec("Pantry", 3), sec("Other", 3)).joinToString("\n")
    ),
    Template(
        "Packing", "Packing", "box",
        listOf(sec("Clothes", 4), sec("Toiletries", 3), sec("Tech", 3), sec("Documents", 2)).joinToString("\n")
    ),
    Template(
        "Day planner", "Today", "ruled",
        "# Morning\n8:00\n9:00\n10:00\n11:00\n# Afternoon\n12:00\n13:00\n14:00\n15:00\n16:00\n# Evening\n17:00\n18:00\n19:00\n20:00",
        true
    ),
    Template("Week", "This week", "ruled", "Mon\nTue\nWed\nThu\nFri\nSat\nSun"),
    Template("Steps", "Steps", "number", blanks(6)),
    Template("Bullets", "", "bullet", blanks(6)),
    Template("Lined paper", "", "ruled", blanks(12))
)
