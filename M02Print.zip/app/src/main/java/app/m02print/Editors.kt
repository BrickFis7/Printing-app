@file:OptIn(ExperimentalMaterial3Api::class)

package app.m02print

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

// ---------------------------------------------------------------- note / list

@Composable
fun TextEditor(vm: AppVm, initial: Doc) {
    var d by remember { mutableStateOf(initial) }
    var tab by remember { mutableIntStateOf(0) }
    BackHandler { vm.closeEditor(d) }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text(if (d.type == DocType.LIST) "List" else "Note") },
                navigationIcon = {
                    IconButton(onClick = { vm.closeEditor(d) }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                actions = {
                    Button(onClick = { vm.upsert(d); vm.print(d) }, enabled = !vm.busy) { Text("Print") }
                    Spacer(Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Edit") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Preview") })
            }
            if (tab == 0) TextEditPane(vm, d) { d = it } else PreviewPane(vm, d)
        }
    }
}

@Composable
fun TextEditPane(vm: AppVm, d: Doc, onChange: (Doc) -> Unit) {
    val isList = d.type == DocType.LIST
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = d.title,
            onValueChange = { onChange(d.copy(title = it)) },
            label = { Text("Title (optional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        if (isList) Chips(LIST_STYLES, d.listStyle) { onChange(d.copy(listStyle = it)) }
        OutlinedTextField(
            value = d.body,
            onValueChange = { onChange(d.copy(body = it)) },
            label = { Text(if (isList) "Items" else "Text") },
            supportingText = {
                if (isList) Text("One item per line. A blank line prints an empty slot. Start a line with “# ” for a heading.")
            },
            minLines = 6,
            modifier = Modifier.fillMaxWidth()
        )
        FontRow(vm, d.font) { onChange(d.copy(font = it)) }
        SliderRow("Size  ${d.size}", d.size.toFloat(), 14f..72f) { onChange(d.copy(size = it.roundToInt())) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = d.bold, onClick = { onChange(d.copy(bold = !d.bold)) }, label = { Text("Bold") })
            FilterChip(selected = d.showDate, onClick = { onChange(d.copy(showDate = !d.showDate)) }, label = { Text("Date") })
        }
        Text(if (isList) "Title alignment" else "Alignment", style = MaterialTheme.typography.labelMedium)
        Chips(ALIGNS, d.align.toString()) { onChange(d.copy(align = it.toInt())) }
    }
}

@Composable
fun PreviewPane(vm: AppVm, d: Doc) {
    val bmp by rememberPreview(vm, d)
    var copies by remember { mutableIntStateOf(1) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Paper(bmp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { if (copies > 1) copies-- }) { Text("−") }
            Text("$copies ×")
            OutlinedButton(onClick = { if (copies < 20) copies++ }) { Text("+") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.upsert(d); vm.print(d, copies) }, enabled = !vm.busy) { Text("Print") }
        }
    }
}

// ---------------------------------------------------------------- image

@Composable
fun ImageEditor(vm: AppVm, initial: Doc) {
    var d by remember { mutableStateOf(initial) }
    val bmp by rememberPreview(vm, d)
    BackHandler { vm.closeEditor(d) }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Image") },
                navigationIcon = {
                    IconButton(onClick = { vm.closeEditor(d) }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                actions = {
                    Button(onClick = { vm.upsert(d); vm.print(d) }, enabled = !vm.busy) { Text("Print") }
                    Spacer(Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Box(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
                contentAlignment = Alignment.TopCenter
            ) { Paper(bmp) }

            Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                Column(
                    Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState()).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Chips(DITHERS, d.dither) { d = d.copy(dither = it) }
                    SliderRow("Brightness  ${d.brightness}", d.brightness.toFloat(), -100f..100f) {
                        d = d.copy(brightness = it.roundToInt())
                    }
                    SliderRow("Contrast  ${d.contrast}", d.contrast.toFloat(), -100f..100f) {
                        d = d.copy(contrast = it.roundToInt())
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { d = d.copy(rotation = (d.rotation + 90) % 360) }) { Text("Rotate 90°") }
                        FilterChip(selected = d.invert, onClick = { d = d.copy(invert = !d.invert) }, label = { Text("Invert") })
                    }
                    OutlinedTextField(
                        value = d.body,
                        onValueChange = { d = d.copy(body = it) },
                        label = { Text("Caption (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (d.body.isNotBlank()) {
                        FontRow(vm, d.font) { d = d.copy(font = it) }
                        SliderRow("Caption size  ${d.size}", d.size.toFloat(), 12f..48f) { d = d.copy(size = it.roundToInt()) }
                    }
                }
            }
        }
    }
}
