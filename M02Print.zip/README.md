# M02 Print

Small Android app for the Phomemo M02 thermal printer: notes, list templates, photos
(with dithering) and a free image library, all printed as 1-bit raster.

- Kotlin + Jetpack Compose, no Room/Coil/Retrofit. Min Android 8.0.
- Connects over Bluetooth Classic (SPP) and falls back to BLE automatically.
- Fonts: 10 system fonts plus import your own .ttf/.otf (Settings > Fonts).
- Image library: Wikimedia Commons and Openverse (no API keys).

## Build
Push this folder to GitHub and run the "Build APK" workflow. The APK is attached to the
"latest-apk" release and to the workflow run as an artifact. Or locally: `gradle assembleDebug`.

## If printing misbehaves
All printer commands live in `Printer.kt`, object `M02`. Things you may need to adjust:
- Garbled / shifted image: Settings > Print width (384 for M02/T02, 576 for M02S/Pro).
- Too light or dark: Settings > Darkness. Default 4. If output breaks after changing it, set it back to 4.
- Paper not clearing the tear bar: raise "Extra paper after each print".
- Won't connect: pair the printer in Android Bluetooth settings first, then pick it in the app.
  The error message shows both the Classic and BLE failure reasons.

## Image licences
Library images carry their own licences (mostly Creative Commons). The picker shows author and
licence, and can print a credit line under the image.
